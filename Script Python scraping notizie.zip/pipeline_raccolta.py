"""
pipeline_raccolta.py
--------------------
Raccoglie articoli dal Nagorno-Karabakh su MediaCloud in due modalità:

  --modalita generale   : ricerca multilingua ampia su tutti i periodi
  --modalita mirata     : integrazione mirata per nazioni sotto-rappresentate
  --modalita entrambe   : esegue prima generale, poi mirata (default)

Output:
  - dataset_notizie_grezzo_multilingua.csv   (modalità generale)
  - dataset_raccolta_mirata.csv              (modalità mirata)

Uso:
  python pipeline_raccolta.py
  python pipeline_raccolta.py --modalita generale
  python pipeline_raccolta.py --modalita mirata --file_attuale path/al/csv_con_nazionalita.csv
"""

import sys
import os
import time
import argparse
from datetime import date

import mediacloud.api as mc
import pandas as pd
import tldextract

# Importa il modulo condiviso nella stessa cartella
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config_e_utils as utils

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# ============================================================
# CONFIGURAZIONE — modifica qui i parametri principali
# ============================================================
mc_search = mc.SearchApi(utils.API_KEY_MEDIACLOUD)

# --- Modalità GENERALE ---
QUERY_MULTILINGUA = [
    "Nagorno-Karabakh",        # Inglese / Internazionale
    "Nagornyi Karabakh",       # Russo traslitterato
    "Daglik Karabag",          # Turco traslitterato
    "Qarabag",                 # Azero
    "Artsakh",                 # Armeno traslitterato
    "ناغورنو كاراباخ",         # Arabo
    "Haut-Karabakh",           # Francese
    "Bergkarabach",            # Tedesco
    "Alto Karabaj",            # Spagnolo
    "Nagorno Karabakh China",  # Per intercettare media cinesi in inglese
    "Karabakh Iran",           # Per intercettare media iraniani in inglese
]

PERIODI = [
    (date(2020, 9, 27), date(2020, 11, 10)),  # Guerra dei 44 giorni
    (date(2021, 1, 1),  date(2021, 12, 31)),  # Periodo interlocutorio
    (date(2022, 1, 1),  date(2022, 12, 31)),  # Pre-escalation 2023
    (date(2023, 9, 1),  date(2023, 10, 15)),  # Operazione militare azera → resa Armenia
]

TARGET_ARTICOLI_GENERALE = 2000
OUTPUT_GENERALE = "dataset_notizie_grezzo_multilingua.csv"

# --- Modalità MIRATA ---
NAZIONI_TARGET = {
    "Azerbaijan":     {"query": "Qarabağ",           "lingua": "AZ"},
    "Russia":         {"query": "Нагорный Карабах",  "lingua": "RU"},
    "Iran":           {"query": "قره‌باغ",            "lingua": "FA"},
    "Turkey":         {"query": "Dağlık Karabağ",    "lingua": "TR"},
    "France":         {"query": "Haut-Karabakh",     "lingua": "FR"},
    "United Kingdom": {"query": "Nagorno-Karabakh",  "lingua": "EN"},
}

TARGET_COUNT_PER_NAZIONE = 30  # Minimo articoli per ogni nazione target
OUTPUT_MIRATA = "dataset_raccolta_mirata.csv"

PERIODI_MIRATA = [
    (date(2020, 9, 27), date(2020, 11, 10)),
    (date(2021, 1, 1),  date(2021, 6, 30)),
    (date(2022, 1, 1),  date(2022, 6, 30)),
    (date(2023, 9, 1),  date(2023, 10, 15)),
]


# ============================================================
# MODALITÀ 1: RACCOLTA GENERALE
# ============================================================
def raccolta_generale():
    print("=" * 60)
    print("MODALITÀ GENERALE: Raccolta URL da MediaCloud")
    print("=" * 60)

    tutti_gli_url = []
    url_visti = set()

    # --- FASE 1: Raccolta URL con paginazione ---
    for query in QUERY_MULTILINGUA:
        for data_inizio, data_fine in PERIODI:
            try:
                print(f"\nRicerca: '{query[:35]}' | {data_inizio} → {data_fine}", flush=True)
            except Exception:
                print(f"\nRicerca: [query multilingua] | {data_inizio} → {data_fine}", flush=True)

            try:
                pagination_token = None
                pagina = 0

                while True:
                    pagina += 1
                    kwargs = dict(start_date=data_inizio, end_date=data_fine)
                    if pagination_token:
                        kwargs['pagination_token'] = pagination_token

                    risultati, pagination_token = mc_search.story_list(query, **kwargs)

                    nuovi = 0
                    for item in risultati:
                        url = item.get('url', '')
                        if url and url not in url_visti:
                            url_visti.add(url)
                            tutti_gli_url.append({
                                'Query_Lingua': query,
                                'Periodo':      f"{data_inizio}/{data_fine}",
                                'Fonte':        item.get('media_name', 'N/A'),
                                'Lingua':       item.get('language', 'N/A'),
                                'Data':         item.get('publish_date', 'N/A'),
                                'Titolo':       item.get('title', 'N/A'),
                                'URL':          url,
                            })
                            nuovi += 1

                    print(f"  -> Pagina {pagina}: {nuovi} nuovi URL  (Totale: {len(tutti_gli_url)})", flush=True)

                    if not pagination_token or not risultati:
                        break

                    time.sleep(0.3)

            except Exception as e:
                print(f"  ERRORE: {e}")

            time.sleep(0.5)

    print(f"\nURL TOTALI (senza duplicati): {len(tutti_gli_url)}")

    # --- FASE 2: Estrazione testo con newspaper3k ---
    print("\n" + "=" * 60)
    print("Estrazione testi con newspaper3k")
    print("=" * 60)

    from newspaper import Article

    dataset_finale = []
    errori = 0

    for i, art in enumerate(tutti_gli_url):
        if len(dataset_finale) >= TARGET_ARTICOLI_GENERALE:
            print(f"\nRaggiunto obiettivo: {TARGET_ARTICOLI_GENERALE} articoli salvati!")
            break

        url = art['URL']
        print(f"[{i+1}/{len(tutti_gli_url)}] Salvati:{len(dataset_finale)} | {url[:65]}...", flush=True)

        try:
            articolo = Article(url)
            articolo.download()
            articolo.parse()
            testo = articolo.text
            if len(testo) > 150:
                art['Testo_Originale'] = testo
                dataset_finale.append(art)
        except Exception:
            errori += 1

        time.sleep(1)

    # --- FASE 3: Salvataggio ---
    print("\n" + "=" * 60)
    print("Salvataggio dataset generale")
    print("=" * 60)

    df = pd.DataFrame(dataset_finale)
    df.to_csv(OUTPUT_GENERALE, index=False, encoding='utf-8-sig')

    print(f"Articoli salvati con successo:   {len(dataset_finale)}")
    print(f"Articoli non leggibili (errori): {errori}")
    print(f"File: {OUTPUT_GENERALE}")
    print("\nProssimi passi -> pipeline_elaborazione.py per traduzione e nazionalità")


# ============================================================
# MODALITÀ 2: RACCOLTA MIRATA (integrazione per nazioni carenti)
# ============================================================
def raccolta_mirata(file_attuale=None):
    print("=" * 60)
    print("MODALITÀ MIRATA: Integrazione per nazioni carenti")
    print("=" * 60)

    # Controlla conteggi attuali
    current_counts = {}
    if file_attuale and os.path.exists(file_attuale):
        try:
            df_att = pd.read_csv(file_attuale)
            current_counts = df_att['Nazionalita_Testata'].value_counts().to_dict()
            print(f"Dataset attuale caricato: {len(df_att)} articoli")
        except Exception as e:
            print(f"Errore lettura file attuale: {e}")
    else:
        print("Nessun dataset attuale fornito: ricerco tutto dall'inizio.")

    print("\n--- STATO ATTUALE DELLE NAZIONI TARGET ---")
    needs_scraping = []
    for nazione in NAZIONI_TARGET:
        cnt = current_counts.get(nazione, 0)
        mancanti = TARGET_COUNT_PER_NAZIONE - cnt
        stato = "OK" if mancanti <= 0 else f"MANCANO {mancanti}"
        print(f"  {nazione:18s}: {cnt:4d} articoli  [{stato}]")
        if mancanti > 0:
            needs_scraping.append((nazione, mancanti))

    if not needs_scraping:
        print("\nTutte le nazioni target hanno già raggiunto l'obiettivo!")
        return

    print(f"\nNazioni da integrare: {[n for n, _ in needs_scraping]}\n")

    risultati_nuovi = []
    url_gia_raccolti = set()

    # Deduplica rispetto al file attuale
    if file_attuale and os.path.exists(file_attuale):
        try:
            df_att = pd.read_csv(file_attuale, usecols=['URL'])
            url_gia_raccolti = set(df_att['URL'].astype(str))
        except Exception:
            pass

    # Deduplica rispetto all'output mirata precedente
    if os.path.exists(OUTPUT_MIRATA):
        try:
            df_old = pd.read_csv(OUTPUT_MIRATA, usecols=['URL'])
            url_gia_raccolti |= set(df_old['URL'].astype(str))
        except Exception:
            pass

    for nazione, mancanti in needs_scraping:
        info = NAZIONI_TARGET[nazione]
        query = info["query"]
        lingua = info["lingua"]
        trovati = 0

        print(f"> {nazione} (mancano {mancanti}) | Query: '{query}' | Lingua: {lingua}")

        for d_start, d_end in PERIODI_MIRATA:
            if trovati >= mancanti:
                break

            try:
                risorse, _ = mc_search.story_list(query, start_date=d_start, end_date=d_end)
                for item in risorse:
                    if trovati >= mancanti:
                        break
                    url = item.get('url', '')
                    if not url or url in url_gia_raccolti:
                        continue

                    # Identificazione "on the fly"
                    paese_rilevato = utils.identifica_nazionalita_mediacloud(item, url)

                    # Accetta se combacia (gestisce alias comuni es. 'UK' vs 'United Kingdom')
                    match = (
                        paese_rilevato.lower() == nazione.lower()
                        or (nazione == 'United Kingdom' and paese_rilevato.lower() in ['uk', 'gb'])
                        or (nazione == 'United States'  and paese_rilevato.lower() in ['us', 'usa'])
                    )

                    if match:
                        url_gia_raccolti.add(url)
                        risultati_nuovi.append({
                            'Query':              query[:30],
                            'Lingua':             lingua,
                            'Periodo':            f"{d_start}/{d_end}",
                            'Fonte':              item.get('media_name', 'N/A'),
                            'Nazionalita_Testata': nazione,
                            'Lang_Art':           item.get('language', 'N/A'),
                            'Data':               item.get('publish_date', 'N/A'),
                            'Titolo':             str(item.get('title', ''))[:120],
                            'URL':                url,
                        })
                        trovati += 1
                        print(f"  [+] {url[:80]}")

                time.sleep(5)  # Rispetta rate limit MediaCloud

            except Exception as e:
                print(f"  ERRORE MediaCloud: {e} — Attendo 20s...")
                time.sleep(20)

        print(f"  Completato {nazione}: trovati {trovati} nuovi articoli.\n")

    # Salvataggio output mirata
    if risultati_nuovi:
        df_new = pd.DataFrame(risultati_nuovi)
        if os.path.exists(OUTPUT_MIRATA):
            df_old = pd.read_csv(OUTPUT_MIRATA)
            df_new = pd.concat([df_old, df_new], ignore_index=True).drop_duplicates(subset='URL')

        df_new.to_csv(OUTPUT_MIRATA, index=False, encoding='utf-8-sig')
        print(f"Salvati {len(df_new)} articoli in: {OUTPUT_MIRATA}")
    else:
        print("Nessun articolo nuovo trovato soddisfacente la nazione richiesta.")

    print("\nProssimo passo -> pipeline_elaborazione.py per testi e traduzione")


# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Raccoglie articoli su Nagorno-Karabakh da MediaCloud."
    )
    parser.add_argument(
        "--modalita", "-m",
        choices=["generale", "mirata", "entrambe"],
        default="entrambe",
        help="Modalità di raccolta (default: entrambe)"
    )
    parser.add_argument(
        "--file_attuale", "-f",
        type=str,
        default=None,
        help="(Solo modalità mirata) CSV con nazionalità già presenti, per calcolare le lacune"
    )
    args = parser.parse_args()

    if args.modalita in ("generale", "entrambe"):
        raccolta_generale()

    if args.modalita in ("mirata", "entrambe"):
        raccolta_mirata(file_attuale=args.file_attuale)
