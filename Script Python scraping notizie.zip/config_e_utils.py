"""
config_e_utils.py
-----------------
Modulo condiviso: contiene tutte le mappe geografiche (ccTLD, domini noti,
keyword, dateline) e le funzioni di utilità per:
  - identificare la nazionalità di una testata dal suo URL/IP/testo
  - tradurre blocchi di testo in inglese con Google Translate

Importato da pipeline_raccolta.py e pipeline_elaborazione.py.
NON va eseguito direttamente.
"""

import socket
import time
import textwrap
import requests
import tldextract

# ============================================================
# CONFIGURAZIONE GLOBALE
# ============================================================
API_KEY_MEDIACLOUD = "7b1aeb13862ea611ccea7b8fd2db2d51399370c3"

# ============================================================
# MAPPE GEOGRAFICHE
# ============================================================

# Principali ccTLD usati dalle testate giornalistiche
ccTLD_MAP = {
    'uk': 'United Kingdom', 'us': 'United States', 'au': 'Australia',
    'ca': 'Canada', 'in': 'India', 'nz': 'New Zealand', 'za': 'South Africa',
    'ie': 'Ireland', 'ng': 'Nigeria', 'ph': 'Philippines', 'sg': 'Singapore',
    'pk': 'Pakistan', 'my': 'Malaysia', 'ke': 'Kenya', 'gh': 'Ghana',
    'it': 'Italy', 'fr': 'France', 'de': 'Germany', 'es': 'Spain',
    'ru': 'Russia', 'tr': 'Turkey', 'az': 'Azerbaijan', 'am': 'Armenia',
    'ir': 'Iran', 'cn': 'China', 'jp': 'Japan', 'kr': 'South Korea',
    'ch': 'Switzerland', 'nl': 'Netherlands', 'se': 'Sweden', 'no': 'Norway',
    'dk': 'Denmark', 'fi': 'Finland', 'pl': 'Poland', 'be': 'Belgium',
    'at': 'Austria', 'gr': 'Greece', 'cz': 'Czech Republic', 'ro': 'Romania',
    'pt': 'Portugal', 'hu': 'Hungary', 'bg': 'Bulgaria', 'ua': 'Ukraine',
    'ae': 'United Arab Emirates', 'sa': 'Saudi Arabia', 'il': 'Israel',
    'eg': 'Egypt', 'ma': 'Morocco', 'dz': 'Algeria', 'tn': 'Tunisia',
    'ar': 'Argentina', 'br': 'Brazil', 'mx': 'Mexico', 'cl': 'Chile',
    'co': 'Colombia', 'pe': 'Peru', 've': 'Venezuela', 'af': 'Afghanistan',
    'tj': 'Tajikistan', 'uz': 'Uzbekistan', 'vn': 'Vietnam', 'rs': 'Serbia',
    'hr': 'Croatia', 'ba': 'Bosnia and Herzegovina', 'md': 'Moldova',
    'lv': 'Latvia', 'tw': 'Taiwan', 'id': 'Indonesia'
}

# Domini specifici noti (massima priorità, sovrascrivono TLD e IP)
KNOWN_DOMAINS = {
    'dawn.com': 'Pakistan',
    'dailysabah.com': 'Turkey',
    'theepochtimes.com': 'United States',
    'newsweek.com': 'United States',
    'nbcnews.com': 'United States',
    'yahoo.com': 'United States',
    'sky.com': 'United Kingdom',
    'brasil247.com': 'Brazil',
    'bbc.com': 'United Kingdom',
    'washingtonpost.com': 'United States',
    'apnews.com': 'United States',
    'rferl.org': 'United States',
    'aljazeera.com': 'Qatar',
    'reuters.com': 'United Kingdom',
    'agenzianova.com': 'Italy',
    'noticiasaominuto.com': 'Portugal',
    'news18.com': 'India',
    'tass.com': 'Russia',
    'indiatimes.com': 'India',
    'straitstimes.com': 'Singapore',
    'menafn.com': 'Jordan',
    'ifpnews.com': 'Iran',
    'jpost.com': 'Israel',
    'ltn.com.tw': 'Taiwan',
    'winnipegfreepress.com': 'Canada',
    'mymcmurray.com': 'Canada',
    'infobae.com': 'Argentina',
    'vnexpress.net': 'Vietnam',
    'voanews.com': 'United States',
    'whbl.com': 'United States',
    'antaranews.com': 'Indonesia',
    'tuttosport.com': 'Italy',
    'sandiegouniontribune.com': 'United States',
    'kvia.com': 'United States',
    'mynews13.com': 'United States',
    'baynews9.com': 'United States',
    'news4jax.com': 'United States',
    'wsls.com': 'United States',
    'ksat.com': 'United States',
    'clickorlando.com': 'United States',
    'clickondetroit.com': 'United States',
    'ncregister.com': 'United States',
    'wmbdradio.com': 'United States',
    'kfgo.com': 'United States',
    'wiky.com': 'United States',
    'wibqam.com': 'United States',
    '740thefan.com': 'United States',
    'ktvz.com': 'United States',
    'kesq.com': 'United States',
    'abc17news.com': 'United States',
    'creativedestructionmedia.com': 'United States'
}

# Keyword nel nome di dominio → nazione
DOMAIN_KEYWORDS = {
    'afghanistan': 'Afghanistan', 'albania': 'Albania', 'algeria': 'Algeria',
    'angola': 'Angola', 'argentina': 'Argentina', 'armenia': 'Armenia',
    'australia': 'Australia', 'austria': 'Austria', 'azerbaijan': 'Azerbaijan',
    'bahrain': 'Bahrain', 'bangladesh': 'Bangladesh', 'belarus': 'Belarus',
    'belgium': 'Belgium', 'bolivia': 'Bolivia', 'bosnia': 'Bosnia and Herzegovina',
    'brazil': 'Brazil', 'bulgaria': 'Bulgaria', 'cambodia': 'Cambodia',
    'cameroon': 'Cameroon', 'canada': 'Canada', 'chile': 'Chile', 'china': 'China',
    'colombia': 'Colombia', 'congo': 'Congo', 'croatia': 'Croatia', 'cuba': 'Cuba',
    'cyprus': 'Cyprus', 'czech': 'Czech Republic', 'denmark': 'Denmark',
    'ecuador': 'Ecuador', 'egypt': 'Egypt', 'ethiopia': 'Ethiopia',
    'finland': 'Finland', 'france': 'France', 'georgia': 'Georgia',
    'germany': 'Germany', 'ghana': 'Ghana', 'greece': 'Greece',
    'guatemala': 'Guatemala', 'hungary': 'Hungary', 'iceland': 'Iceland',
    'india': 'India', 'indonesia': 'Indonesia', 'iran': 'Iran', 'iraq': 'Iraq',
    'ireland': 'Ireland', 'israel': 'Israel', 'italy': 'Italy', 'japan': 'Japan',
    'jordan': 'Jordan', 'kazakhstan': 'Kazakhstan', 'kenya': 'Kenya',
    'korea': 'South Korea', 'kosovo': 'Kosovo', 'kuwait': 'Kuwait',
    'kyrgyzstan': 'Kyrgyzstan', 'latvia': 'Latvia', 'lebanon': 'Lebanon',
    'libya': 'Libya', 'lithuania': 'Lithuania', 'luxembourg': 'Luxembourg',
    'madagascar': 'Madagascar', 'malaysia': 'Malaysia', 'mali': 'Mali',
    'malta': 'Malta', 'mauritania': 'Mauritania', 'mexico': 'Mexico',
    'moldova': 'Moldova', 'mongolia': 'Mongolia', 'montenegro': 'Montenegro',
    'morocco': 'Morocco', 'mozambique': 'Mozambique', 'myanmar': 'Myanmar',
    'nepal': 'Nepal', 'netherlands': 'Netherlands', 'newzealand': 'New Zealand',
    'nicaragua': 'Nicaragua', 'nigeria': 'Nigeria', 'macedonia': 'North Macedonia',
    'norway': 'Norway', 'oman': 'Oman', 'pakistan': 'Pakistan', 'panama': 'Panama',
    'peru': 'Peru', 'philippines': 'Philippines', 'poland': 'Poland',
    'portugal': 'Portugal', 'qatar': 'Qatar', 'romania': 'Romania',
    'russia': 'Russia', 'rwanda': 'Rwanda', 'saudi': 'Saudi Arabia',
    'senegal': 'Senegal', 'serbia': 'Serbia', 'singapore': 'Singapore',
    'slovakia': 'Slovakia', 'slovenia': 'Slovenia', 'somalia': 'Somalia',
    'southafrica': 'South Africa', 'spain': 'Spain', 'srilanka': 'Sri Lanka',
    'sudan': 'Sudan', 'sweden': 'Sweden', 'switzerland': 'Switzerland',
    'syria': 'Syria', 'taiwan': 'Taiwan', 'tajikistan': 'Tajikistan',
    'tanzania': 'Tanzania', 'thailand': 'Thailand', 'tunisia': 'Tunisia',
    'turkey': 'Turkey', 'turkmenistan': 'Turkmenistan', 'uganda': 'Uganda',
    'ukraine': 'Ukraine', 'emirates': 'United Arab Emirates',
    'uae': 'United Arab Emirates', 'uk': 'United Kingdom',
    'usa': 'United States', 'america': 'United States',
    'uruguay': 'Uruguay', 'uzbekistan': 'Uzbekistan', 'venezuela': 'Venezuela',
    'vietnam': 'Vietnam', 'yemen': 'Yemen', 'zambia': 'Zambia',
    'zimbabwe': 'Zimbabwe',
    # Testate specifiche note
    'panarmenian': 'Armenia', 'azernews': 'Azerbaijan', 'asbarez': 'Armenia',
    'hurriyet': 'Turkey', 'aljazeera': 'Qatar', 'alarabiya': 'Saudi Arabia'
}

# Città/Regioni tipiche nelle dateline del testo dell'articolo
DATELINE_MAP = {
    'RABAT': 'Morocco', 'CASABLANCA': 'Morocco',
    'ABUJA': 'Nigeria', 'LAGOS': 'Nigeria', 'NAIROBI': 'Kenya', 'ACCRA': 'Ghana',
    'YEREVAN': 'Armenia', 'STEPANAKERT': 'Armenia', 'BAKU': 'Azerbaijan',
    'ANKARA': 'Turkey', 'ISTANBUL': 'Turkey',
    'MOSCOW': 'Russia', 'ST. PETERSBURG': 'Russia',
    'NEW DELHI': 'India', 'MUMBAI': 'India',
    'ISLAMABAD': 'Pakistan', 'KARACHI': 'Pakistan',
    'BEIRUT': 'Lebanon', 'AMMAN': 'Jordan',
    'ADDIS ABABA': 'Ethiopia', 'MOGADISHU': 'Somalia',
    'BEIJING': 'China', 'SHANGHAI': 'China',
    'TOKYO': 'Japan', 'SEOUL': 'South Korea',
    'TEHRAN': 'Iran', 'KABUL': 'Afghanistan',
    'WASHINGTON': 'United States', 'NEW YORK': 'United States',
    'LONDON': 'United Kingdom', 'PARIS': 'France',
    'BERLIN': 'Germany', 'ROME': 'Italy'
}

# ============================================================
# FUNZIONI: IDENTIFICAZIONE NAZIONALITÀ
# ============================================================

def get_country_from_tld(ext):
    """Controlla se il TLD è un country code (ccTLD) e restituisce la nazione."""
    suffix = ext.suffix.split('.')[-1].lower()
    return ccTLD_MAP.get(suffix)


def get_country_from_domain_keywords(domain):
    """Controlla se il nome del dominio contiene parole chiave associate a una nazione."""
    domain_lower = domain.lower()
    for kw, country in DOMAIN_KEYWORDS.items():
        if kw in domain_lower:
            return country
    return None


def get_country_from_text(text):
    """Cerca dateline nel testo dell'articolo (es: 'RABAT -') per risalire alla nazione."""
    if not isinstance(text, str) or len(text) < 20:
        return None
    prefix = text[:100].upper()
    for city, country in DATELINE_MAP.items():
        if city in prefix and ('-' in prefix or ',' in prefix):
            return country
    return None


def get_country_from_ip(domain):
    """Geolocalizza il dominio via IP (ip-api.com). Ultimo fallback, bassa confidenza."""
    try:
        ip = socket.gethostbyname(domain)
    except Exception:
        return None
    try:
        headers = {'User-Agent': 'NationalityFinder/1.0'}
        resp = requests.get(
            f"http://ip-api.com/json/{ip}?fields=country",
            timeout=5, headers=headers
        ).json()
        if resp.get("status") != "fail":
            return resp.get("country")
    except Exception:
        pass
    return None


def identifica_nazionalita_dominio(dominio, fonte=None, testo=None, use_ip=True):
    """
    Identifica la nazione di una testata partendo dal suo dominio registrato.
    Cascata di metodi: Known → TLD → Keyword → Dateline → Fonte → IP.
    Restituisce la stringa della nazione o 'Unknown'.
    """
    if not dominio:
        return "Unknown"

    # 0. Domini noti (massima priorità)
    if dominio in KNOWN_DOMAINS:
        return KNOWN_DOMAINS[dominio]

    ext = tldextract.extract(dominio)

    # 1. ccTLD
    nazione = get_country_from_tld(ext)
    if nazione:
        return nazione

    # 2. Keyword nel dominio
    nazione = get_country_from_domain_keywords(dominio)
    if nazione:
        return nazione

    # 3. Dateline nel testo
    if testo:
        nazione = get_country_from_text(testo)
        if nazione:
            return nazione

    # 4. Keyword nel nome della fonte
    if isinstance(fonte, str):
        for kw, country in DOMAIN_KEYWORDS.items():
            if kw in fonte.lower():
                return country

    # 5. Geolocalizzazione IP (bassa confidenza)
    if use_ip:
        nazione = get_country_from_ip(dominio)
        time.sleep(1.5)  # Rispetta rate limit ip-api.com (45 req/min gratuiti)
        if nazione:
            return nazione

    return "Unknown"


def identifica_nazionalita_mediacloud(item, url):
    """
    Identifica la nazione "on the fly" dai metadati MediaCloud + fallback URL.
    Usato durante la raccolta mirata per evitare un secondo passaggio.
    """
    # Prova prima i metadati MediaCloud
    pub = item.get('media_pub_country') or item.get('pub_country')
    if pub and isinstance(pub, str) and len(pub) > 1:
        if len(pub) == 2:
            return ccTLD_MAP.get(pub.lower(), pub)
        return pub

    # Fallback: analisi URL
    dom = tldextract.extract(str(url)).registered_domain
    return identifica_nazionalita_dominio(dom, use_ip=False)


# ============================================================
# FUNZIONI: TRADUZIONE
# ============================================================

def traduci_testo(testo, translator, chunk_size=4900, pausa=0.5):
    """
    Traduce un testo in inglese spezzandolo in chunk per rispettare
    il limite di 5000 caratteri di Google Translate.
    Restituisce la stringa tradotta o stringa vuota in caso di errore.
    """
    if not testo or len(testo) < 50:
        return testo

    chunks = textwrap.wrap(testo, chunk_size, break_long_words=False)
    parti = []
    for chunk in chunks:
        try:
            trad = translator.translate(chunk)
            if trad:
                parti.append(trad)
        except Exception as e:
            print(f"    ! Errore traduzione chunk: {e}")
        time.sleep(pausa)

    return " ".join(parti)
