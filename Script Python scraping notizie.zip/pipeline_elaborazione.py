"""
pipeline_elaborazione.py
-------------------------
Elabora uno o più CSV di URL grezzi eseguendo in sequenza:

  1. Identificazione nazionalità della testata (se non già presente)
  2. Estrazione del testo completo con newspaper3k
  3. Traduzione in inglese con Google Translate (a chunking sicuro)
  4. Salvataggio del dataset finale pronto per l'analisi R/STM

Gestisce checkpoint automatici ogni 20 articoli per resistere a
interruzioni di rete o di esecuzione.

Uso:
  # Input singolo (default: dataset_notizie_grezzo_multilingua.csv)
  python pipeline_elaborazione.py

  # Input multipli + file precedente per deduplicazione
  python pipeline_elaborazione.py \\
      --input dataset_notizie_grezzo_multilingua.csv dataset_raccolta_mirata.csv \\
      --precedente dataset_tradotto_finale.csv \\
      --output dataset_elaborato_finale.csv

  # Salta la traduzione (solo estrazione testo + nazionalità)
  python pipeline_elaborazione.py --no_traduzione
"""

import sys
import os
import time
import argparse

import pandas as pd
import tldextract
from newspaper import Article
from deep_translator import GoogleTranslator

# Importa il modulo condiviso nella stessa cartella
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config_e_utils as utils

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# ============================================================
# CONFIGURAZIONE DEFAULT
# ============================================================
DEFAULT_INPUT      = ["dataset_notizie_grezzo_multilingua.csv"]
DEFAULT_PRECEDENTE = None   # CSV già tradotto per deduplicazione
DEFAULT_OUTPUT     = "dataset_elaborato_finale.csv"
DEFAULT_CHECKPOINT = "dataset_elaborato_checkpoint.csv"
CHECKPOINT_OGNI    = 20     # Salva checkpoint ogni N articoli
SOGLIA_TESTO       = 80     # Caratteri minimi per conservare un testo


# ============================================================
# FASE 1: IDENTIFICAZIONE NAZIONALITÀ (batch su tutto il DF)
# ============================================================
def aggiungi_nazionalita(df, usa_ip=True):
    """
    Aggiunge la colonna 'Nazionalita_Testata' al dataframe se mancante
    o parzialmente vuota. Lavora per dominio unico per ridurre le chiamate IP.
    """
    if 'Nazionalita_Testata' not in df.columns:
        df['Nazionalita_Testata'] = None

    # Estrai dominio registrato per ogni riga
    if 'Dominio' not in df.columns:
        df['Dominio'] = df['URL'].apply(
            lambda x: tldextract.extract(str(x)).registered_domain
        )

    # Identifica solo i domini con nazionalità mancante/sconosciuta
    mask_mancante = df['Nazionalita_Testata'].isna() | (df['Nazionalita_Testata'] == 'Unknown')
    domini_da_identificare = df.loc[mask_mancante, 'Dominio'].dropna().unique()

    if len(domini_da_identificare) == 0:
        print("Nazionalità già presenti per tutti gli articoli.")
        return df

    print(f"Identificazione nazionalità per {len(domini_da_identificare)} domini unici...")

    # Costruisci cache testo e fonte per dominio (prende il primo campione disponibile)
    testo_per_dominio = {}
    fonte_per_dominio = {}
    if 'Testo_Originale' in df.columns:
        for dom in domini_da_identificare:
            samples = df[df['Dominio'] == dom]['Testo_Originale'].dropna()
            if not samples.empty:
                testo_per_dominio[dom] = samples.iloc[0]
    if 'Fonte' in df.columns:
        for dom in domini_da_identificare:
            fonti = df[df['Dominio'] == dom]['Fonte'].dropna()
            if not fonti.empty:
                fonte_per_dominio[dom] = fonti.iloc[0]

    mapping = {}
    for i, dom in enumerate(domini_da_identificare):
        print(f"  [{i+1}/{len(domini_da_identificare)}] {dom:35s} -> ", end="", flush=True)
        nazione = utils.identifica_nazionalita_dominio(
            dom,
            fonte=fonte_per_dominio.get(dom),
            testo=testo_per_dominio.get(dom),
            use_ip=usa_ip
        )
        mapping[dom] = nazione
        print(nazione)

    # Applica il mapping solo alle righe mancanti
    df.loc[mask_mancante, 'Nazionalita_Testata'] = df.loc[mask_mancante, 'Dominio'].map(mapping)

    print("\n--- Riepilogo Nazionalità ---")
    print(df['Nazionalita_Testata'].value_counts().to_string())

    return df


# ============================================================
# FASE 2+3: ESTRAZIONE TESTO + TRADUZIONE (articolo per articolo)
# ============================================================
def estrai_e_traduci(df, output_csv, checkpoint_csv, traduci=True):
    """
    Per ogni riga del dataframe:
      - Scarica e parsifica l'articolo con newspaper3k
      - (Opzionale) Traduce il testo in inglese con Google Translate
      - Salva checkpoint ogni CHECKPOINT_OGNI articoli
    """
    translator = GoogleTranslator(source='auto', target='en') if traduci else None

    # Ripristino checkpoint
    dati = []
    url_processati = set()

    if os.path.exists(checkpoint_csv):
        try:
            df_check = pd.read_csv(checkpoint_csv)
            dati = df_check.to_dict('records')
            url_processati = set(df_check['URL'].astype(str))
            print(f"Checkpoint trovato! Riprendo da {len(dati)} articoli già elaborati.")
        except Exception as e:
            print(f"Errore lettura checkpoint: {e}")

    errori_estrazione  = 0
    errori_traduzione  = 0
    totale             = len(df)

    print("\n" + "=" * 60)
    fase = "ESTRAZIONE + TRADUZIONE" if traduci else "ESTRAZIONE TESTO"
    print(f"INIZIO {fase}")
    print("=" * 60)

    for idx, (_, row) in enumerate(df.iterrows()):
        url = str(row.get('URL', ''))
        if not url or url == 'nan' or url in url_processati:
            continue

        print(f"[{idx+1}/{totale}] {url[:75]}...", flush=True)

        # -- Estrazione testo --
        testo_originale = str(row.get('Testo_Originale', ''))
        if len(testo_originale) < SOGLIA_TESTO:
            # Il testo non era già nel CSV: scaricalo
            try:
                articolo = Article(url)
                articolo.download()
                articolo.parse()
                testo_originale = articolo.text
                if len(testo_originale) < SOGLIA_TESTO:
                    testo_originale = ""
                    print("  ~ Testo troppo breve, ignorato.")
            except Exception as e:
                errori_estrazione += 1
                testo_originale = ""
                print(f"  ! Errore estrazione: {e}")

        # -- Traduzione --
        testo_inglese = ""
        if traduci and len(testo_originale) >= SOGLIA_TESTO:
            try:
                testo_inglese = utils.traduci_testo(testo_originale, translator)
            except Exception as e:
                errori_traduzione += 1
                print(f"  ! Errore traduzione: {e}")
        elif not traduci:
            testo_inglese = ""  # colonna vuota se traduzione disabilitata

        # -- Costruzione riga output --
        riga = {
            'URL':                url,
            'Fonte':              str(row.get('Fonte', '')),
            'Data':               str(row.get('Data', '')),
            'Titolo':             str(row.get('Titolo', ''))[:200],
            'Query_Lingua':       str(row.get('Query_Lingua', row.get('Query', ''))),
            'Lingua_Originale':   str(row.get('Lingua', row.get('Lang_Art', ''))),
            'Nazionalita_Testata': str(row.get('Nazionalita_Testata', 'Unknown')),
            'Testo_Originale':    testo_originale,
        }
        if traduci:
            riga['Testo_Inglese'] = testo_inglese

        dati.append(riga)
        url_processati.add(url)

        # Salva checkpoint
        if len(dati) % CHECKPOINT_OGNI == 0:
            pd.DataFrame(dati).to_csv(checkpoint_csv, index=False, encoding='utf-8-sig')
            print(f"  [CHECKPOINT] Salvati finora: {len(dati)}")

        time.sleep(1)

    # -- Salvataggio finale --
    df_finale = pd.DataFrame(dati)

    # Riordina colonne: testo originale subito prima del tradotto
    cols = list(df_finale.columns)
    if traduci and 'Testo_Originale' in cols and 'Testo_Inglese' in cols:
        cols.insert(cols.index('Testo_Originale') + 1, cols.pop(cols.index('Testo_Inglese')))
        df_finale = df_finale[cols]

    df_finale.to_csv(output_csv, index=False, encoding='utf-8-sig')

    print("\n" + "=" * 60)
    print("ELABORAZIONE COMPLETATA!")
    print(f"  Articoli processati:       {len(dati)}")
    print(f"  Errori estrazione:         {errori_estrazione}")
    if traduci:
        print(f"  Errori traduzione:         {errori_traduzione}")
    print(f"  File output:               {output_csv}")
    print("=" * 60)
    print("\nProsegui con lo script R per unire ai dataset precedenti!")


# ============================================================
# MAIN
# ============================================================
def main():
    parser = argparse.ArgumentParser(
        description="Elabora URL grezzi: estrae testi, identifica nazionalità e traduce."
    )
    parser.add_argument(
        "--input", "-i",
        nargs="+",
        default=DEFAULT_INPUT,
        help="Uno o più CSV di URL da elaborare (default: dataset_notizie_grezzo_multilingua.csv)"
    )
    parser.add_argument(
        "--precedente", "-p",
        type=str,
        default=DEFAULT_PRECEDENTE,
        help="CSV già elaborato in precedenza (per deduplicazione URL)"
    )
    parser.add_argument(
        "--output", "-o",
        type=str,
        default=DEFAULT_OUTPUT,
        help=f"File CSV di output (default: {DEFAULT_OUTPUT})"
    )
    parser.add_argument(
        "--no_ip",
        action="store_true",
        help="Disabilita la geolocalizzazione via IP (più veloce ma meno accurata)"
    )
    parser.add_argument(
        "--no_traduzione",
        action="store_true",
        help="Salta la traduzione: solo estrazione testo + identificazione nazionalità"
    )
    args = parser.parse_args()

    checkpoint_csv = args.output.replace(".csv", "_checkpoint.csv")

    # ---- Caricamento e unione dei file di input ----
    print("Caricamento e unione dei file sorgente...")
    dfs = []
    for f in args.input:
        if os.path.exists(f):
            df_tmp = pd.read_csv(f)
            print(f"  -> {os.path.basename(f)}: {len(df_tmp)} righe")
            dfs.append(df_tmp)
        else:
            print(f"  ATTENZIONE: {f} non trovato, saltato.")

    if not dfs:
        print("Nessun file di input trovato. Uscita.")
        sys.exit(1)

    df_input = pd.concat(dfs, ignore_index=True).drop_duplicates(subset='URL')
    print(f"URL unici totali: {len(df_input)}")

    # ---- Deduplicazione rispetto al dataset precedente ----
    if args.precedente and os.path.exists(args.precedente):
        df_prev = pd.read_csv(args.precedente, usecols=['URL'])
        url_precedenti = set(df_prev['URL'].astype(str))
        prima = len(df_input)
        df_input = df_input[~df_input['URL'].astype(str).isin(url_precedenti)]
        print(f"Rimossi {prima - len(df_input)} URL già presenti nel dataset precedente.")

    print(f"Articoli da processare definitivamente: {len(df_input)}")

    # ---- FASE 1: Identificazione nazionalità ----
    print("\n" + "=" * 60)
    print("FASE 1: Identificazione Nazionalità")
    print("=" * 60)
    df_input = aggiungi_nazionalita(df_input, usa_ip=not args.no_ip)

    # ---- FASE 2+3: Estrazione testo + traduzione ----
    estrai_e_traduci(
        df_input,
        output_csv=args.output,
        checkpoint_csv=checkpoint_csv,
        traduci=not args.no_traduzione
    )


if __name__ == "__main__":
    main()
